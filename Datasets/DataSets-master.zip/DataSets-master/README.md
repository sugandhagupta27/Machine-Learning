# DataSets
This is Data Set for implementing classification and Regression algorithms
